using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using ConfigurationReaderLib;
using System.Text.Json;
using System.IO;
using Microsoft.AspNetCore.SignalR;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSingleton<IConfigurationStore>(sp => new JsonFileConfigurationStore("storage/configs.json"));
builder.Services.AddSingleton<IConfigurationChangePublisher>(sp => {
    try { return new RabbitMqPublisher(builder.Configuration.GetValue<string>("RabbitMqHost") ?? "localhost"); } catch { return null!; }
});

builder.Services.AddSignalR();
builder.Services.AddSingleton<ConfigurationReader>(sp =>
{
    var store = sp.GetRequiredService<IConfigurationStore>();
    IConfigurationChangePublisher? publisher = null;
    try { publisher = sp.GetService<IConfigurationChangePublisher>(); } catch { }
    return new ConfigurationReader("SERVICE-A", store, 5000, publisher);
});

var app = builder.Build();

app.MapGet("/api/configs", (IConfigurationStore store) =>
{
    var all = store.GetAllAsync("SERVICE-A").GetAwaiter().GetResult();
    var actives = all.Where(r => r.IsActive && string.Equals(r.ApplicationName, "SERVICE-A", StringComparison.OrdinalIgnoreCase));
    return Results.Json(actives);
});

app.MapPost("/api/configs", async (ConfigurationRecord rec) =>
{
    var path = "storage/configs.json";
    var list = System.Text.Json.JsonSerializer.Deserialize<List<ConfigurationRecord>>(File.ReadAllText(path)) ?? new List<ConfigurationRecord>();
    var nextId = (list.Count > 0) ? list.Max(x => x.Id) + 1 : 1;
    var toAdd = rec with { Id = nextId };
    list.Add(toAdd);
    File.WriteAllText(path, System.Text.Json.JsonSerializer.Serialize(list, new System.Text.Json.JsonSerializerOptions { WriteIndented = true }));
    return Results.Created($"/api/configs/{nextId}", toAdd);
});

app.MapGet("/", () => Results.Content(File.ReadAllText("wwwroot/index.html"), "text/html"));

app.MapHub<ConfigHub>("/confighub");

app.UseStaticFiles();

try
{
    var hubContext = app.Services.GetRequiredService<IHubContext<ConfigHub>>();
    var rabbitHost = builder.Configuration.GetValue<string>("RabbitMqHost") ?? "localhost";
    var listener = new ConfigurationChangeListener(rabbitHost, hubContext);
    app.Lifetime.ApplicationStopping.Register(() => listener.Dispose());
}
catch { }

app.Run();
