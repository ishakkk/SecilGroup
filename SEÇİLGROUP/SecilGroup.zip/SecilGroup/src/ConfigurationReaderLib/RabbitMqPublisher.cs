using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using RabbitMQ.Client;

namespace ConfigurationReaderLib
{
    public class RabbitMqPublisher : IConfigurationChangePublisher, System.IDisposable
    {
        private readonly IConnection _connection;
        private readonly IModel _channel;
        private readonly string _exchange = "config_changes";
        public RabbitMqPublisher(string hostName = "localhost") { var factory = new ConnectionFactory() { HostName = hostName }; _connection = factory.CreateConnection(); _channel = _connection.CreateModel(); _channel.ExchangeDeclare(exchange: _exchange, type: ExchangeType.Fanout, durable: false, autoDelete: true); }
        public Task PublishChangeAsync(ConfigurationRecord record) { var body = JsonSerializer.Serialize(record); var bytes = Encoding.UTF8.GetBytes(body); _channel.BasicPublish(exchange: _exchange, routingKey: "", basicProperties: null, body: bytes); return Task.CompletedTask; }
        public void Dispose() { _channel?.Close(); _connection?.Close(); }
    }
}
