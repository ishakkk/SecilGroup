using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ConfigurationReaderLib
{
    public class ConfigurationReader : IDisposable
    {
        private readonly string _applicationName;
        private readonly int _refreshMs;
        private readonly IConfigurationStore _store;
        private readonly IConfigurationChangePublisher? _publisher;
        private readonly ConcurrentDictionary<string, ConfigurationRecord> _cache = new();
        private readonly ReaderWriterLockSlim _cacheLock = new();
        private Timer? _timer;
        private bool _disposed;

        public ConfigurationReader(string applicationName, IConfigurationStore store, int refreshTimerIntervalInMs, IConfigurationChangePublisher? publisher = null)
        {
            _applicationName = applicationName ?? throw new ArgumentNullException(nameof(applicationName));
            _store = store ?? throw new ArgumentNullException(nameof(store));
            _refreshMs = Math.Max(1000, refreshTimerIntervalInMs);
            _publisher = publisher;

            LoadSnapshotAsync().GetAwaiter().GetResult();
            _timer = new Timer(async _ => await RefreshIfNeededAsync(), null, _refreshMs, _refreshMs);
        }

        private async Task LoadSnapshotAsync()
        {
            var all = await _store.GetAllAsync(_applicationName);
            var actives = all.Where(r => r.IsActive && string.Equals(r.ApplicationName, _applicationName, StringComparison.OrdinalIgnoreCase));
            _cacheLock.EnterWriteLock();
            try
            {
                _cache.Clear();
                foreach (var rec in actives)
                    _cache[rec.Name] = rec;
            }
            finally { _cacheLock.ExitWriteLock(); }
        }

        private async Task RefreshIfNeededAsync()
        {
            try
            {
                var all = await _store.GetAllAsync(_applicationName);
                var actives = all.Where(r => r.IsActive && string.Equals(r.ApplicationName, _applicationName, StringComparison.OrdinalIgnoreCase)).ToList();

                _cacheLock.EnterUpgradeableReadLock();
                try
                {
                    foreach (var rec in actives)
                    {
                        if (!_cache.TryGetValue(rec.Name, out var existing) || existing.Value != rec.Value)
                        {
                            _cacheLock.EnterWriteLock();
                            try { _cache[rec.Name] = rec; }
                            finally { _cacheLock.ExitWriteLock(); }
                            _ = PublishChangeSafeAsync(rec);
                        }
                    }

                    var keysToRemove = _cache.Keys.Except(actives.Select(a => a.Name)).ToList();
                    if (keysToRemove.Any())
                    {
                        _cacheLock.EnterWriteLock();
                        try { foreach (var k in keysToRemove) _cache.TryRemove(k, out _); }
                        finally { _cacheLock.ExitWriteLock(); }
                    }
                }
                finally { _cacheLock.ExitUpgradeableReadLock(); }
            }
            catch { }
        }

        private async Task PublishChangeSafeAsync(ConfigurationRecord rec)
        {
            try { if (_publisher != null) await _publisher.PublishChangeAsync(rec); }
            catch { }
        }

        public T GetValue<T>(string key)
        {
            if (string.IsNullOrWhiteSpace(key)) throw new ArgumentNullException(nameof(key));

            _cacheLock.EnterReadLock();
            try
            {
                if (!_cache.TryGetValue(key, out var rec))
                    throw new KeyNotFoundException($"Key '{key}' not found for application '{_applicationName}'.");

                return ConvertValue<T>(rec.Value, rec.Type);
            }
            finally { _cacheLock.ExitReadLock(); }
        }

        private static T ConvertValue<T>(string value, string typeName)
        {
            if (typeof(T) == typeof(string)) return (T)(object)value;
            typeName = typeName?.ToLowerInvariant() ?? string.Empty;
            try
            {
                if (typeName.StartsWith("int") || typeof(T) == typeof(int)) return (T)(object)int.Parse(value);
                if (typeName.StartsWith("bool") || typeof(T) == typeof(bool)) return (T)(object)bool.Parse(value);
                if (typeName.StartsWith("double") || typeof(T) == typeof(double)) return (T)(object)double.Parse(value);
                if (typeName.StartsWith("long") || typeof(T) == typeof(long)) return (T)(object)long.Parse(value);
                if (typeof(T).IsEnum) return (T)Enum.Parse(typeof(T), value, true);
                return (T)System.Convert.ChangeType(value, typeof(T));
            }
            catch (Exception ex) { throw new InvalidCastException($"Cannot convert value '{{value}}' to type {typeof(T).FullName}: {{ex.Message}}", ex); }
        }

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            _timer?.Dispose();
            _cacheLock?.Dispose();
            (_store as IDisposable)?.Dispose();
            (_publisher as IDisposable)?.Dispose();
        }
    }
}
