using System;
using System.Text;
using System.Text.Json;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using Microsoft.AspNetCore.SignalR;

namespace ConfigurationReaderLib
{
    public class ConfigurationChangeListener : IDisposable
    {
        private readonly IConnection _connection;
        private readonly IModel _channel;
        private readonly IHubContext<ConfigHub> _hubContext;
        private readonly string _exchange = "config_changes";
        private readonly string _queueName;
        private readonly EventingBasicConsumer _consumer;

        public ConfigurationChangeListener(string rabbitHost, IHubContext<ConfigHub> hubContext)
        {
            _hubContext = hubContext ?? throw new ArgumentNullException(nameof(hubContext));
            var factory = new ConnectionFactory() { HostName = rabbitHost };
            _connection = factory.CreateConnection();
            _channel = _connection.CreateModel();
            _channel.ExchangeDeclare(exchange: _exchange, type: ExchangeType.Fanout, durable: false, autoDelete: true);

            _queueName = _channel.QueueDeclare().QueueName;
            _channel.QueueBind(queue: _queueName, exchange: _exchange, routingKey: "");

            _consumer = new EventingBasicConsumer(_channel);
            _consumer.Received += async (model, ea) =>
            {
                try
                {
                    var body = ea.Body.ToArray();
                    var json = Encoding.UTF8.GetString(body);
                    var rec = JsonSerializer.Deserialize<ConfigurationRecord>(json);
                    if (rec != null)
                    {
                        await _hubContext.Clients.All.SendAsync("configChanged", rec);
                    }
                }
                catch { }
            };

            _channel.BasicConsume(queue: _queueName, autoAck: true, consumer: _consumer);
        }

        public void Dispose()
        {
            try { _channel?.Close(); } catch { }
            try { _connection?.Close(); } catch { }
        }
    }
}
