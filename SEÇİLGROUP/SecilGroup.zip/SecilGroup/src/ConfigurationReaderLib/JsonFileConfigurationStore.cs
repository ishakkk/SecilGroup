using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;

namespace ConfigurationReaderLib
{
    public class JsonFileConfigurationStore : IConfigurationStore, IDisposable
    {
        private readonly string _filePath;
        public JsonFileConfigurationStore(string filePath) { _filePath = string.IsNullOrWhiteSpace(filePath) ? "storage/configs.json" : filePath; Directory.CreateDirectory(Path.GetDirectoryName(_filePath) ?? "storage"); if (!File.Exists(_filePath)) { var sample = new[] { new ConfigurationRecord(1, "SiteName", "string", "soty.io", true, "SERVICE-A") }; File.WriteAllText(_filePath, JsonSerializer.Serialize(sample, new JsonSerializerOptions { WriteIndented = true })); } }
        public Task<IEnumerable<ConfigurationRecord>> GetAllAsync(string applicationName) { var json = File.ReadAllText(_filePath); var arr = JsonSerializer.Deserialize<List<ConfigurationRecord>>(json); return Task.FromResult<IEnumerable<ConfigurationRecord>>(arr ?? new List<ConfigurationRecord>()); }
        public void Dispose() { }
    }
}
